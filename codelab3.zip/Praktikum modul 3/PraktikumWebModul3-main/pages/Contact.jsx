// src/pages/Contact.js
import React from 'react';

function ContactPage() {
  return (
    <div>
      <h2>Contact</h2>
      {/* Isi dengan konten Contact */}
    </div>
  );
}

export default ContactPage;
