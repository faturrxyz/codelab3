// src/pages/Menu.js
import React from 'react';
import bg from '../assets/download.jpeg';

function Menu() {
  return (
    <div>
      <h2>Menu</h2>
      <img src={bg} alt='tes'></img>
    </div>
  );
}

export default Menu;


